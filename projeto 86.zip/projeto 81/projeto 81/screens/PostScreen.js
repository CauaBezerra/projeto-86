import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  Image,
  ScrollView,
  Dimensions
} from "react-native";

export default class PostScreen extends Component {

    render() {
        return (
            <View style={styles.container}>
              <SafeAreaView style={styles.droidSafeArea} />
              <View style={styles.appTitle}>
                <View style={styles.appIcon}>
                  <Image
                    source={require("../assets/logo.png")}
                  ></Image>
                </View>
                <View style={styles.appTitleTextContainer}>
                  <Text style={styles.appTitleText}>App Espectagrama</Text>
                </View>
              </View>
              <View style={styles.postContainer}>
                <ScrollView style={styles.postCard}>
                  <Image
                    source={require("../assets/image_1.png")}
                    style={styles.image}
                  ></Image>
    
                  <View style={styles.dataContainer}>
                    <View style={styles.titleTextContainer}>
                    </View>
                  </View>
                  <View style={styles.postTextContainer}>
                    <Text style={styles.postText}>
                      {this.props.route.params.post.text}
                    </Text>
                  </View>
                  <View style={styles.actionContainer}>
                    <View style={styles.likeButton}>
                      <Ionicons name={"heart"} size={RFValue(30)} color={"white"} />
                      <Text style={styles.likeText}>12k</Text>
                    </View>
                  </View>
                </ScrollView>
              </View>
            </View>
        );
    }

}