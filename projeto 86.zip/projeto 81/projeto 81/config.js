export const firebaseConfig = {
    apiKey: "AIzaSyCq0m7PtYAIw5ajrIiKLFA8o7zMS0mRZkE",
    authDomain: "app-espectagrama-70dad.firebaseapp.com",
    projectId: "app-espectagrama-70dad",
    storageBucket: "app-espectagrama-70dad.appspot.com",
    messagingSenderId: "936565212755",
    appId: "1:936565212755:web:4068d4945804fcd54928a6"
  };